# views/__init__.py

# 빈 파일이거나, 다음과 같이 최소한의 주석만 포함할 수 있습니다.
# This file is intentionally left blank.
