# attendance/views/admin_views.py
import pandas as pd
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.core.mail import send_mail
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import ListView, CreateView, UpdateView, DeleteView

from ..models import Semester, Course, Class, Lecturer, Student, User, Attendance


# 관리자 대시보드
@login_required
def admin_dashboard(request):
    return render(request, 'attendance/admin/admin_dashboard.html')


# 로그인 후 사용자 권한에 따라 각기 다른 페이지로 리디렉션
@login_required
def dashboard(request):
    user = request.user
    if user.is_superuser:
        return redirect('admin-dashboard')
    elif user.groups.filter(name='Lecturer').exists():
        return redirect('lecturer-class-list')
    elif user.groups.filter(name='Student').exists():
        return redirect('student-attendance')
    else:
        return redirect('home')


# Attendance Check View
@login_required
def attendance_check(request, class_id):
    class_instance = get_object_or_404(Class, pk=class_id)

    # 관리자가 아니고 강사가 아니라면 접근 제한
    if not request.user.is_superuser and request.user != class_instance.lecturer.user:
        messages.error(request, 'You do not have permission to access this page.')
        return redirect('class-list')

    students = class_instance.students.all()  # 수업에 등록된 모든 학생 가져오기
    today = timezone.now().date()

    if request.method == 'POST':
        for student in students:
            status = request.POST.get(f'status_{student.id}')
            if status:
                Attendance.objects.update_or_create(
                    student=student,
                    class_instance=class_instance,
                    date=today,
                    defaults={'status': status}
                )
        messages.success(request, 'Attendance has been updated successfully.')
        return redirect('class-list')

    context = {
        'class_instance': class_instance,
        'students': students,
        'today': today,
    }
    return render(request, 'attendance/admin/attendance_check.html', context)


# Send Attendance Warning View
@login_required
def send_attendance_warning(request, class_id):
    class_instance = get_object_or_404(Class, pk=class_id)

    # 관리자가 아니고 강사가 아니라면 접근 제한
    if not request.user.is_superuser and request.user != class_instance.lecturer.user:
        messages.error(request, 'You do not have permission to access this page.')
        return redirect('class-list')

    students_with_issues = Student.objects.filter(
        attendance__class_instance=class_instance,
        attendance__status__in=['A', 'L']
    ).distinct()

    for student in students_with_issues:
        send_mail(
            'Attendance Warning',
            f'Dear {student.user.get_full_name()},\n\n'
            'You have been marked as Absent or Late multiple times for the class '
            f'{class_instance.course.name}. Please ensure that you attend the classes regularly.',
            'admin@yourdomain.com',
            [student.user.email],
            fail_silently=False,
        )

    messages.success(request, 'Attendance warning emails have been sent.')
    return redirect('class-list')


@login_required
def upload_student_excel(request):
    if request.method == 'POST' and request.FILES['student_file']:
        excel_file = request.FILES['student_file']
        df = pd.read_excel(excel_file)
        for index, row in df.iterrows():
            user, created = User.objects.get_or_create(username=row['username'], defaults={'email': row['email']})
            student, created = Student.objects.get_or_create(user=user, student_id=row['student_id'], DOB=row['DOB'])
        return redirect('student-list')
    return render(request, 'attendance/admin/upload_student.html')


def calculate_attendance_rate(student, class_instance):
    """
    학생의 특정 수업에 대한 출석률을 계산합니다.
    :param student: Student 객체
    :param class_instance: Class 객체
    :return: 출석률 (0~100 사이의 정수)
    """
    # 해당 학생의 특정 수업에 대한 출석 기록을 가져옴
    total_classes = Attendance.objects.filter(student=student, class_instance=class_instance).count()

    if total_classes == 0:
        return 0  # 출석 기록이 없을 경우 0% 반환

    # 출석 상태가 'Present'인 경우만 카운트
    attended_classes = Attendance.objects.filter(student=student, class_instance=class_instance, status='P').count()

    # 출석률 계산
    attendance_rate = (attended_classes / total_classes) * 100
    return round(attendance_rate)


# Semester mgt.

# 학기 목록 보기
class SemesterListView(LoginRequiredMixin, ListView):
    model = Semester
    template_name = 'attendance/admin/semester_list.html'
    context_object_name = 'semesters'


# 학기 생성
class SemesterCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Semester
    fields = ['year', 'semester']
    template_name = 'attendance/admin/semester_form.html'
    success_url = reverse_lazy('semester-list')
    permission_required = 'attendance.add_semester'


# 학기 수정
class SemesterUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Semester
    fields = ['year', 'semester']
    template_name = 'attendance/admin/semester_form.html'
    success_url = reverse_lazy('semester-list')
    permission_required = 'attendance.change_semester'


# 학기 삭제
class SemesterDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Semester
    template_name = 'attendance/admin/semester_confirm_delete.html'
    success_url = reverse_lazy('semester-list')
    permission_required = 'attendance.delete_semester'


# Course mgt.

# 과목 목록 보기
class CourseListView(LoginRequiredMixin, ListView):
    model = Course
    template_name = 'attendance/admin/course_list.html'
    context_object_name = 'courses'


# 과목 생성
class CourseCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Course
    fields = ['code', 'name']
    template_name = 'attendance/admin/course_form.html'
    success_url = reverse_lazy('course-list')
    permission_required = 'attendance.add_course'


# 과목 수정
class CourseUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Course
    fields = ['code', 'name']
    template_name = 'attendance/admin/course_form.html'
    success_url = reverse_lazy('course-list')
    permission_required = 'attendance.change_course'


# 과목 삭제
class CourseDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Course
    template_name = 'attendance/admin/course_confirm_delete.html'
    success_url = reverse_lazy('course-list')
    permission_required = 'attendance.delete_course'


# Class mgt.

# 수업 목록 보기
class ClassListView(LoginRequiredMixin, ListView):
    model = Class
    template_name = 'attendance/admin/class_list.html'
    context_object_name = 'classes'


# 수업 생성
class ClassCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Class
    fields = ['number', 'course', 'semester', 'lecturer']
    template_name = 'attendance/admin/class_form.html'
    success_url = reverse_lazy('class-list')
    permission_required = 'attendance.add_class'


# 수업 수정
class ClassUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Class
    fields = ['number', 'course', 'semester', 'lecturer']
    template_name = 'attendance/admin/class_form.html'
    success_url = reverse_lazy('class-list')
    permission_required = 'attendance.change_class'


# 수업 삭제
class ClassDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Class
    template_name = 'attendance/admin/class_confirm_delete.html'
    success_url = reverse_lazy('class-list')
    permission_required = 'attendance.delete_class'


# Lecturer mgt.

# 강사 목록 보기
class LecturerListView(LoginRequiredMixin, ListView):
    model = Lecturer
    template_name = 'attendance/admin/lecturer_list.html'
    context_object_name = 'lecturers'


# 강사 생성
class LecturerCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Lecturer
    fields = ['user', 'staff_id', 'DOB']
    template_name = 'attendance/admin/lecturer_form.html'
    success_url = reverse_lazy('lecturer-list')
    permission_required = 'attendance.add_lecturer'


# 강사 수정
class LecturerUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Lecturer
    fields = ['user', 'staff_id', 'DOB']
    template_name = 'attendance/admin/lecturer_form.html'
    success_url = reverse_lazy('lecturer-list')
    permission_required = 'attendance.change_lecturer'


# 강사 삭제
class LecturerDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Lecturer
    template_name = 'attendance/admin/lecturer_confirm_delete.html'
    success_url = reverse_lazy('lecturer-list')
    permission_required = 'attendance.delete_lecturer'


# Student mgt.

# 학생 목록 보기
class StudentListView(LoginRequiredMixin, ListView):
    model = Student
    template_name = 'attendance/admin/student_list.html'
    context_object_name = 'students'


# 학생 생성
class StudentCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Student
    fields = ['user', 'student_id', 'DOB']
    template_name = 'attendance/admin/student_form.html'
    success_url = reverse_lazy('student-list')
    permission_required = 'attendance.add_student'


# 학생 수정
class StudentUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Student
    fields = ['user', 'student_id', 'DOB']
    template_name = 'attendance/admin/student_form.html'
    success_url = reverse_lazy('student-list')
    permission_required = 'attendance.change_student'


# 학생 삭제
class StudentDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Student
    template_name = 'attendance/admin/student_confirm_delete.html'
    success_url = reverse_lazy('student-list')
    permission_required = 'attendance.delete_student'
