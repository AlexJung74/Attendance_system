# student_views.py

from django.views.generic import DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import redirect
from django.contrib import messages
from ..models import Student


class StudentAttendanceView(LoginRequiredMixin, DetailView):
    model = Student
    template_name = "attendance/student/student_attendance.html"
    context_object_name = 'student'

    def get_object(self, queryset=None):
        try:
            return self.request.user.student  # 현재 로그인한 학생의 출석 정보만 표시
        except Student.DoesNotExist:
            # Student 객체가 없는 경우 예외 처리
            messages.error(self.request, "You are not associated with a student account.")
            return redirect('home')  # 홈으로 리디렉션하거나 다른 페이지로 이동
