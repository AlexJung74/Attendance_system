# views/lecturer_views.py

from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView

from ..models import Class, Attendance, Student


# 강사 수업 목록 보기
class ClassListView(LoginRequiredMixin, ListView):
    model = Class
    template_name = 'attendance/lecturer/class_list.html'
    context_object_name = 'classes'

    def get_queryset(self):
        return Class.objects.filter(lecturer=self.request.user.lecturer)


@login_required
def lecturer_dashboard(request):
    user = request.user

    # 강사 그룹에 속해 있는지 확인
    is_lecturer = user.groups.filter(name='Lecturer').exists()

    # 현재 강사의 수업 목록 가져오기
    lecturer_classes = Class.objects.filter(lecturer__user=user)

    context = {
        'lecturer_classes': lecturer_classes,
        'is_lecturer': is_lecturer  # 템플릿에 is_lecturer 변수 전달
    }
    return render(request, 'attendance/lecturer/lecturer_dashboard.html', context)


# 특정 수업의 출석 체크 페이지
@login_required
def lecturer_attendance_check(request, class_id):
    class_instance = get_object_or_404(Class, id=class_id, lecturer=request.user.lecturer)
    students = Student.objects.filter(class__id=class_instance.id)
    if request.method == 'POST':
        for student in students:
            status = request.POST.get(f'status_{student.id}')
            Attendance.objects.create(
                student=student,
                class_instance=class_instance,
                date=request.POST.get('date'),
                status=status
            )
        return redirect('lecturer-class-list')
    return render(request, 'attendance/lecturer/attendance_check.html', {
        'class_instance': class_instance,
        'students': students
    })
