from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.

# 1. User 모델 (Django 기본 User 모델을 확장)
class User(AbstractUser):
    # 추가 필드만 정의
    phone_number = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return self.username


# 2. Student 모델 (User와 1:1 관계)
class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student')
    student_id = models.CharField(max_length=20, unique=True)
    DOB = models.DateField()  # Date of Birth
    classes = models.ManyToManyField('Class', related_name='students')  # Class와의 관계 추가

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name} - {self.student_id}"


# 3. Lecturer 모델 (User와 1:1 관계)
class Lecturer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    staff_id = models.CharField(max_length=20, unique=True)
    DOB = models.DateField()  # Date of Birth

    def __str__(self):
        return f"{self.user.first_name} {self.user.last_name} - {self.staff_id}"


# 4. Semester 모델
class Semester(models.Model):
    year = models.IntegerField()  # 학년도
    semester = models.CharField(max_length=10)  # 학기 (예: 'Spring', 'Fall')

    def __str__(self):
        return f"{self.year} {self.semester}"


# 5. Course 모델
class Course(models.Model):
    code = models.CharField(max_length=10, unique=True)  # 과목 코드
    name = models.CharField(max_length=100)  # 과목 이름

    def __str__(self):
        return self.name


# 6. Class 모델
class Class(models.Model):
    number = models.IntegerField()  # 수업 번호
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='classes')  # Course와의 관계
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE, related_name='classes')  # Semester와의 관계
    lecturer = models.ForeignKey(Lecturer, on_delete=models.CASCADE, related_name='classes')  # Lecturer와의 관계

    def __str__(self):
        return f"{self.course.name} - Class {self.number} ({self.semester})"


# 7. CollegeDay 모델
class CollegeDay(models.Model):
    date = models.DateField()  # 날짜
    class_obj = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='college_days')  # Class와의 관계

    def __str__(self):
        return f"{self.class_obj} on {self.date}"


# 8. Attendance 모델: 출석 정보 관리
class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    class_instance = models.ForeignKey(Class, on_delete=models.CASCADE)
    date = models.DateField()  # 출석 날짜
    status_choices = [
        ('P', 'Present'),
        ('A', 'Absent'),
        ('L', 'Late'),
        ('E', 'Excused'),
    ]
    status = models.CharField(max_length=1, choices=status_choices)  # 출석 상태

    def __str__(self):
        return f"{self.student} - {self.class_instance} - {self.date}: {self.get_status_display()}"
