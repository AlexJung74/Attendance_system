# utils.py

from django.core.mail import send_mail
from django.conf import settings


def send_attendance_warning_email(student, attendance_rate):
    subject = f'Attendance Warning for {student.user.first_name} {student.user.last_name}'
    message = (f"Dear {student.user.first_name},\n\nYour attendance rate is {attendance_rate}%. Please make sure to "
               f"attend the classes.")
    send_mail(
        subject,
        message,
        settings.EMAIL_HOST_USER,
        [student.user.email]
    )
