# attendance/forms.py

from django import forms
from .models import Student, Lecturer, Course, Class, Semester, Attendance


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['user', 'student_id', 'DOB']


class LecturerForm(forms.ModelForm):
    class Meta:
        model = Lecturer
        fields = ['user', 'staff_id', 'DOB']


class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['code', 'name']


class ClassForm(forms.ModelForm):
    class Meta:
        model = Class
        fields = ['number', 'course', 'semester', 'lecturer']


class SemesterForm(forms.ModelForm):
    class Meta:
        model = Semester
        fields = ['year', 'semester']


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['student', 'class_instance', 'date', 'status']
