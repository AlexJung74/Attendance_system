# attendance/urls.py

from django.contrib import admin
from django.urls import path, include

from attendance.views.home_views import home  # home_views 안의 home 함수 임포트

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),  # 홈 화면 설정
    path('attendance/', include('attendance.urls')),  # attendance 앱의 URL 포함
    path('accounts/', include('django.contrib.auth.urls')),  # 로그인/로그아웃 URL 포함
]